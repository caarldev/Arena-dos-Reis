# Arena Real
Jogo estilo Clash Royale em Python + Kivy — personagens ilustrados, animações, efeitos, sons e música.

## Gerar o APK
1. Suba **todos** os arquivos (incluindo a pasta `assets/`) para o repositório no GitHub.
2. Aba **Actions** > **Build APK** > **Run workflow** (também roda a cada push).
3. Quando terminar (~20-30 min na 1ª vez), baixe o APK em **Artifacts**.

## Testar no PC
    pip install kivy pillow && python main.py

## Como jogar
Toque numa carta e depois na sua metade da arena — ou **arraste a carta** até lá.
A Bola de Fogo pode ir em qualquer lugar. Derrube a torre do Rei inimigo ou tenha
mais torres derrubadas quando o tempo acabar. Nos últimos 60s o elixir é em dobro.

## Trocar a arte e os sons
Tudo fica em `assets/`. Para usar suas próprias imagens, substitua o PNG com o **mesmo nome**
(`cavaleiro.png`, `mago.png`, `arena.png`, ...). Sons: `clique.wav`, `invocar.wav`, `musica.ogg`...
Para regerar a arte/sons originais: `python tools/gerar_assets.py` e `python tools/gerar_sons.py`.
